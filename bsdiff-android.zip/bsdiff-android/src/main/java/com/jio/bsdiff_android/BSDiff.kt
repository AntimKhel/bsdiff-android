package com.jio.bsdiff_android

import android.util.Log
import java.io.File


object BSDiff {
    init {
        System.loadLibrary("bsdiff_android")
    }

    private fun getFileDir(dir: String): String {
        if (dir.startsWith("file://")) {
            return dir.substring(7)
        }
        return dir
    }


    fun patch(oldFile: String?, newFile: String?, patchFile: String?) {
        if (oldFile == null || newFile == null || patchFile == null || oldFile.isEmpty() || newFile.isEmpty() || patchFile.isEmpty()) {
            Log.e("error", "oldFile, newFile, patchFile can not be null or empty")
            return
        }
        if (oldFile == newFile || oldFile == patchFile || newFile == patchFile) {
            Log.e("error", "oldFile, newFile, patchFile can not be the same")
            return
        }
        val oldFileObj = File(getFileDir(oldFile))
        if (!oldFileObj.exists()) {
            Log.e("error", "oldFile: $oldFile not exist")
            return
        }
        val patchFileObj = File(getFileDir(patchFile))
        if (!patchFileObj.exists()) {
            Log.e("error", "patchFile: $patchFile not exist")
            return
        }
        val newFileObj = File(getFileDir(newFile))
        if (newFileObj.exists()) {
            Log.e("error", "newFile: $newFile already exist")
            return
        }
        try {
            val result = bsPatchFile(
                oldFileObj.absolutePath,
                newFileObj.absolutePath,
                patchFileObj.absolutePath
            )
            Log.d("result", result.toString())
        } catch (e: Exception) {
            Log.e("error", e.message.toString())
        }
    }


    fun diff(oldFile: String?, newFile: String?, patchFile: String?) {
        if (oldFile == null || newFile == null || patchFile == null || oldFile.isEmpty() || newFile.isEmpty() || patchFile.isEmpty()) {
            Log.e("error", "oldFile, newFile, patchFile can not be null or empty")
            return
        }
        if (oldFile == newFile || oldFile == patchFile || newFile == patchFile) {
            Log.e("error", "oldFile, newFile, patchFile can not be the same")
            return
        }
        val oldFileObj = File(getFileDir(oldFile))
        if (!oldFileObj.exists()) {
            Log.e("error", "oldFile: $oldFile not exist")
            return
        }
        val newFileObj = File(getFileDir(newFile))
        if (!newFileObj.exists()) {
            Log.e("error", "newFile: $newFile not exist")
            return
        }
        val patchFileObj = File(getFileDir(patchFile))
        if (patchFileObj.exists()) {
            Log.e("error", "patchFile: $patchFile already exist")
            return
        }
        try {
            val result = bsDiffFile(
                oldFileObj.absolutePath,
                newFileObj.absolutePath,
                patchFileObj.absolutePath
            )
            Log.d("result", result.toString())
        } catch (e: Exception) {
            Log.e("error", e.message.toString())
        }
    }

    external fun stringFromJNI(): String

    private external fun bsPatchFile(oldFile: String, newFile: String, patchFile: String): Int

    private external fun bsDiffFile(oldFile: String, newFile: String, patchFile: String): Int
}